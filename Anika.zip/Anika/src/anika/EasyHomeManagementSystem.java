
package anika;



import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class EasyHomeManagementSystem {
    private static Scanner scanner = new Scanner(System.in);
    private static Map<String, String> userDatabase = new HashMap<>();

    public static void main(String[] args) {
        System.out.println("Welcome to EASYHOME");

        while (true) {
            System.out.println("1. Login");
            System.out.println("2. Register");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (option) {
                case 1:
                    login();
                    break;
                case 2:
                    register();
                    break;
                case 3:
                    System.out.println("Exiting EASYHOME. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void login() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        // Check if the provided username and password match
        if (userDatabase.containsKey(username) && userDatabase.get(username).equals(password)) {
            System.out.println("Login successful. Welcome, " + username + "!");
            showMainMenu();
        } else {
            System.out.println("Invalid login. Please try again.");
            
        }
    }

    private static void register() {
        System.out.print("Enter a new username: ");
        String username = scanner.nextLine();
        System.out.print("Enter a password: ");
        String password = scanner.nextLine();

        // Store the new user in the database
        userDatabase.put(username, password);
        System.out.println("Registration successful. You can now log in.");
        
    }

    private static void showMainMenu() {
        while (true) {
            System.out.println("What's on your mind?");
            System.out.println("");
            System.out.println("1. Property Search");
            System.out.println("2. Post Property Ad");
            System.out.println("3. Advice");
            System.out.println("4. Logout");
            System.out.print("Choose an option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (option) {
                case 1:
                    propertySearch();
                    break;
                case 2:
                    postPropertyAd();
                    break;
                case 3:
                    advice();
                    break;
                case 4:
                    System.out.println("Logging out. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void propertySearch() {
        System.out.println("");
        System.out.println("1. Buy Property");
        System.out.println("2. Rent Property");
        System.out.println("");
        System.out.print("Select one : ");
        int searchOption = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.println("1. Individual");
        System.out.println("2. Agent");
        int userOption = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter receiver's phone number: ");
        String phoneNumber = scanner.nextLine();

        System.out.println("Property details for " + phoneNumber + ":");
        System.out.println("");
        System.out.println("1.Bagan bari1");
        System.out.println("Address details : khagan bazar");
        System.out.println("Phone number : 123456789");
        
        System.out.println("");
        System.out.println("1.Bagan bari2");
        System.out.println("Address details : khagan bazar");
        System.out.println("Phone number : 123456789");
        
        System.out.println("");
        System.out.println("1.Bagan bari3");
        System.out.println("Address details : khagan bazar");
        System.out.println("Phone number : 123456789");
        System.out.println("");
        System.out.println("");
        showMainMenu();
        
        // Implement logic to display property details based on search and user options
    }

    private static void postPropertyAd() {
        System.out.println("1. Sell Property");
        System.out.println("2. Rent/Lease Property");
        int adOption = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.println("1. Residential");
        System.out.println("2. Commercial");
        int propertyType = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.println("1. Flat");
        System.out.println("2. House");
        System.out.println("3. Villa");
        System.out.println("4. Plot");
        int specificProperty = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        System.out.println("Give your property information:");
        System.out.print("Location :");
        String location = scanner.nextLine();
        System.out.print("Phone number :");
        String number = scanner.nextLine();
        System.out.print("");
        System.out.println("Your information successfully received !");
        System.out.println("");
        System.out.println("");
        showMainMenu();
        // Implement logic to receive and store property information
    }

    private static void advice() {
        System.out.println("For advice, please contact our call center at +123456789");
    }
}
